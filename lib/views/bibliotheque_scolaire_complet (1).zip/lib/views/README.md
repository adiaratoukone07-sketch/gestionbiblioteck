# Views — Système de Gestion de Bibliothèque Scolaire

Ce dossier correspond au répertoire `lib/views/` de l'arborescence MVC
du cahier des charges (§3.2). Les vues affichent l'interface et
capturent les actions, mais ne contiennent **aucune logique métier ni
accès direct aux DAO** : tout passe par les `controllers/`.

| Fichier              | Statut | Rôle |
|------------------------|--------|------|
| `login_page.dart`     | ✅ fait | Authentification (identifiant + mot de passe), branchée sur `AuthController.connecter()` |
| `accueil_page.dart`   | ✅ fait | Point d'entrée après connexion : 4 cartes vers Adhérents / Livres / Emprunts / Tableau de bord |
| `adherents_page.dart` | ✅ fait | Gestion des adhérents (sidebar dynamique, tableau à colonnes fixes, statuts cliquables, menu contextuel flottant, état vide, formulaire 2 colonnes) |
| `livres_page.dart`    | ✅ fait | Catalogue des livres + exemplaires (RG-06), même patterns que `adherents_page.dart` |
| `prets_page.dart`     | ✅ fait | Emprunts / retours (RG-02, RG-03, RG-04), liste de cartes + filtres En cours/En retard/Tous |
| `dashboard_page.dart` | ✅ fait | Tableau de bord : indicateurs + livres les plus empruntés, via `StatistiqueController` |

Les 6 pages du cahier des charges sont maintenant construites. Toute
la navigation entre modules passe par `Navigator.pushReplacement` (une
page remplace l'autre, pas d'empilement de retours en arrière).

## `livres_page.dart`, `prets_page.dart`, `dashboard_page.dart`

Construites en suivant les mêmes principes que la version finale de
`adherents_page.dart` (formulaire compact, distinction recherche vide
≠ base vide, widgets de ligne à état local pour éviter le clignotement
au survol), mais avec une nouveauté :

- **`lib/widgets/app_shell.dart`** — la sidebar + barre de titre de
  `adherents_page.dart` ont été extraites dans un widget partagé
  (`AppShell`) pour ces 3 nouvelles pages, plutôt que de recopier
  ~150 lignes de sidebar dans chaque fichier. Il reproduit fidèlement
  ton style personnalisé (police Inter, logo `assets/icons/mon_logo.png`,
  couleurs de survol, `withValues(alpha:)`).
- `adherents_page.dart` garde sa propre sidebar interne (déjà écrite et
  personnalisée avant la création d'`AppShell`) plutôt que d'être
  migrée vers le widget partagé, pour ne pas risquer de casser tes
  ajustements — mais sa méthode `_naviguerVersModule` a été mise à jour
  pour naviguer réellement vers `LivresPage`, `PretsPage` et
  `DashboardPage` maintenant qu'elles existent (elle affichait un
  message "bientôt disponible" auparavant). La méthode
  `_buildPlaceholderModule`, devenue inutile, a été supprimée.
- **`prets_page.dart`** utilise une liste de cartes plutôt qu'un
  tableau à colonnes fixes : un emprunt combine des infos de deux
  entités (adhérent + livre/exemplaire), plus lisible empilé qu'aligné
  en colonnes étroites. Le formulaire "Nouvel emprunt" est une boîte
  de dialogue à 2 menus déroulants (adhérent, livre — filtré pour
  n'afficher que les livres ayant au moins un exemplaire disponible),
  plutôt qu'un panneau bas de page.
- **Deux petites méthodes ajoutées aux contrôleurs** pour ces pages :
  `PretController.obtenirTous()` (filtre "Tous" de `prets_page.dart`)
  et `ExemplaireController.obtenirParId()` (retrouver le livre associé
  à un emprunt).

## `login_page.dart` et `accueil_page.dart`

- **2 champs seulement** sur la connexion (identifiant affiché "Nom" +
  mot de passe) : pas de champ "code" séparé — conformément au choix
  retenu, le mot de passe sert aussi de PIN pour le déverrouillage par
  inactivité (`AuthController.deverrouiller`).
- `LoginPage` appelle `AuthController.connecter()` ; en cas de succès,
  navigation (`pushReplacement`) vers `AccueilPage` pour empêcher un
  retour arrière vers l'écran de connexion.
- `AccueilPage` affiche les 4 modules sous forme de cartes. Seule la
  carte "Adhérents" navigue réellement vers `AdherentsPage` ; les
  autres affichent un message temporaire ("bientôt disponible") tant
  que leurs pages ne sont pas construites.
- Le bouton de déconnexion sur `AccueilPage` appelle
  `AuthController.deconnecter()` puis revient à `LoginPage` en vidant
  la pile de navigation (`pushAndRemoveUntil`), pour empêcher un retour
  arrière vers les pages protégées.
- `lib/main.dart` a été ajouté (absent jusqu'ici) : point d'entrée qui
  démarre systématiquement sur `LoginPage`.

### Image de fond de la connexion (`login_page.dart`)

Remplace les formes décoratives précédentes par une vraie image
(`DecorationImage` + `BoxFit.cover`), responsive à toute taille de
fenêtre.

**Dimensions recommandées** :
- **Minimum : 1920 × 1080 px** (Full HD, ratio 16:9) — suffisant pour
  la taille de fenêtre par défaut (`1280×800`, cf. `main.dart`).
- **Conseillé : 2560 × 1440 px** (ratio 16:9) — reste net si
  l'utilisateur agrandit la fenêtre ou est sur un écran haute
  définition. Au-delà (ex. 3840×2160/4K), le gain visuel est marginal
  pour un gain de poids de fichier important.
- Format `.jpg` (photo) recommandé pour le poids ; `.png` si
  transparence nécessaire.

**Mise en place :**
1. Place le fichier dans `assets/images/login_background.jpg`.
2. Déclare-le dans `pubspec.yaml` :
   ```yaml
   flutter:
     assets:
       - assets/images/
   ```
3. `lib/views/login_page.dart` pointe déjà vers ce chemin via la
   constante `_cheminImageFond` — change juste cette constante si le
   nom de fichier diffère.

Tant que l'image n'est pas fournie, un dégradé violet de secours
s'affiche à la place (pas d'écran cassé pendant le développement).

### Cartes jumelées (image livres + formulaire)

Les deux cartes de `login_page.dart` sont maintenant collées (plus
d'espace entre elles) : la carte image n'a d'arrondi qu'à gauche
(`topLeft`/`bottomLeft`), la carte formulaire qu'à droite
(`topRight`/`bottomRight`) — elles se comportent visuellement comme un
seul bloc coupé en deux, conformément à la dernière maquette. Sur un
écran étroit (largeur < 760px), seule la carte formulaire s'affiche,
avec un arrondi complet cette fois (`arrondiComplet: true`).

## Barre de titre personnalisée (toutes les pages)

`login_page.dart`, `accueil_page.dart` et `adherents_page.dart`
utilisent désormais `BarreTitrePersonnalisee`
(`lib/widgets/custom_title_bar.dart`) à la place des icônes
décoratives précédentes : vrais boutons réduire / agrandir / fermer,
stylés à la charte, plus la barre Windows par défaut. Nécessite une
petite configuration native — voir `WINDOWS_SETUP.md` à la racine.

## `adherents_page.dart` — v3, nouvelle maquette (dernière révision)

Refonte visuelle sur la base de la dernière capture fournie. Rappel :
le fond des données (nom, prénom, etc.) reste exactement ce que
l'utilisateur saisit, sans transformation de casse — seuls les
**en-têtes de colonnes** sont volontairement affichés en majuscules.

- **Sidebar en dégradé uni** : les formes décoratives ("taches") en
  bas de la sidebar ont été retirées, ne reste que le dégradé violet.
- **Barre de titre restructurée** : elle ne contient plus le nom du
  module actif (qui bougeait selon la page) — désormais logo +
  "Bibliotech" à gauche (nouveau paramètre `leading` sur
  `BarreTitrePersonnalisee`, cf. `lib/widgets/custom_title_bar.dart`),
  fenêtre toujours déplaçable par cette zone.
- **Nouveau bandeau "compte"** juste sous la barre de titre : dégradé
  violet horizontal, icône + initiales du compte connecté à droite
  (`_libelleCompteCourant`, dérivé de `AuthController.utilisateurCourant`
  — "admin" devient "Ad", comme dans la maquette).
- **Titre de page déplacé dans le contenu** : "Liste des adhérents"
  (constante `_titrePage`) apparaît maintenant en haut de la zone de
  contenu, à gauche, sur la même ligne que le bouton "Nouveau" — plus
  dans la barre de titre.
  ⚠️ La maquette affiche littéralement "Adherent list" (en anglais) ;
  j'ai gardé du français pour rester cohérent avec le reste de l'app.
  Dis-le si tu veux le texte exact de la maquette.
- **Tableau à colonnes fixes, sans "Nom Complet"** : NOM / PRENOM /
  MATRICULE / CLASSE / STATUTS, alignement garanti par
  `construireLigneColonnes()` (colonne "Nom Complet" retirée pour
  coller à la nouvelle maquette).
- **En-tête de tableau en majuscules, fond violet plein** (au lieu
  d'un texte violet sur fond clair) — coins arrondis en haut,
  raccordés à la carte.
- **Plus de défilement interne dans la liste** : remplacé par une
  vraie pagination en bas de la carte (`_buildPagination()`, 8
  adhérents par page — `_taillePage`), avec précédent/suivant et
  fenêtre de numéros de page (première, dernière, pages autour de la
  courante, "…" pour les sauts). La page revient à 1 après tout
  ajout/modification/suppression/recherche (simplification assumée :
  pas de mémorisation de la page en cours après une action).
- **Statut "En cours" en vert** (au lieu de violet), pour matcher la
  maquette ; "Aucun emprunt" reste violet neutre, "En retard" reste
  rouge.
- **Clic sur un badge de statut → vraie navigation** : ouvre
  `PretsPage` avec l'adhérent pré-sélectionné
  (`PretsPage.adherentPreselectionne`), qui ouvre directement le
  formulaire "Nouvel emprunt" avec cet adhérent déjà choisi dans le
  menu déroulant — il ne reste plus qu'à choisir le livre. Ce
  comportement s'applique aux 3 statuts (pas seulement "Aucun
  emprunt") : c'est un raccourci "attribuer un emprunt à cet
  adhérent", peu importe son statut actuel.
- **Barre de recherche séparée** du bouton "Nouveau" (qui est monté à
  côté du titre de page) ; icône de recherche déplacée à droite du
  champ, comme sur la maquette.
- **Sidebar interne conservée** (pas migrée vers `AppShell`) : sa
  navigation pointe vers `AccueilPage`, `LivresPage`, `PretsPage`,
  `DashboardPage`.

### Correctifs des retours précédents, toujours en place

- Alignement des colonnes garanti par une fonction de fichier
  partagée entre l'en-tête et chaque ligne.
- Lignes de séparation (`Divider`) entre chaque ligne de la liste.
- Statut calculé dynamiquement via `PretController`, pas simulé.
- Formulaire compact (padding réduit, `isDense: true`).
- Colonne d'actions élargie (`_largeurColonneActions = 96`) pour que
  le menu crayon/poubelle ne déborde plus.
- Distinction "recherche sans résultat" vs "base vide" (`_baseVide`).
- État vide enveloppé dans un `SingleChildScrollView`, jamais de
  débordement même si l'espace se réduit.
- Clignotement au survol corrigé (`_LigneAdherentWidget` à état local,
  clé stable, marge fixe).
- Suppression confirmée par `AlertDialog`.
- Formulaire à 2 colonnes (Nom/Prénom, Matricule/Classe).
- Simplification assumée, toujours en place : pas d'effet "carrousel"
  où la ligne sélectionnée se déplace visuellement — remplacé par
  surbrillance + ombre + opacité réduite sur les autres lignes.

## Correctif accueil_page.dart : navigation réellement branchée

Les cartes "Livres", "Emprunts" et "Tableau de bord" de `AccueilPage`
appelaient encore `_bientotDisponible()` alors que ces 3 pages
existent désormais — oubli corrigé : elles naviguent maintenant
réellement vers `LivresPage`, `PretsPage`, `DashboardPage` (`Navigator.push`,
pas `pushReplacement`, pour permettre un retour à l'accueil).

## Dépendances requises (`pubspec.yaml`)

```yaml
dependencies:
  google_fonts: ^6.2.1
  bitsdojo_window: ^0.1.6

flutter:
  assets:
    - assets/images/
```
