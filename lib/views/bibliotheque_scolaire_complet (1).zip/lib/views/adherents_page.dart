import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../controllers/adherent_controller.dart';
import '../controllers/auth_controller.dart';
import '../controllers/pret_controller.dart';
import '../controllers/resultat_operation.dart';
import '../models/adherent.dart';
import '../models/pret.dart';
import '../widgets/custom_title_bar.dart';
import 'accueil_page.dart';
import 'dashboard_page.dart';
import 'livres_page.dart';
import 'prets_page.dart';

/// Modules accessibles depuis la sidebar.
enum _ModuleSidebar { home, adherents, livres, emprunts, tableauDeBord }

/// Les 3 états du formulaire bas de page.
enum ModeFormulaire { masque, ajout, modification }

/// Statut d'emprunt affiché dans la colonne "Statuts", calculé à
/// partir de l'historique réel des emprunts via [PretController].
enum _StatutAdherent { aucunEmprunt, enCours, enRetard }

/// Titre affiché en haut de la page (cf. nouvelle maquette : le titre
/// n'est plus dans la barre de fenêtre mais dans le contenu de la page).
const String _titrePage = 'Liste des adhérents';

/// Nombre d'adhérents affichés par page (cf. nouvelle maquette :
/// pagination en bas de la carte liste, plus de défilement interne).
const int _taillePage = 8;

/// Largeur fixe de la colonne d'actions, partagée entre l'en-tête et
/// chaque ligne.
const double _largeurColonneActions = 96;

/// Répartition des colonnes du tableau (Nom, Prénom, Matricule,
/// Classe, Statuts, actions), partagée entre l'en-tête et chaque ligne
/// pour garantir un alignement parfait. La colonne "Nom Complet" de la
/// précédente version a été retirée pour coller à la nouvelle maquette
/// (NOM / PRENOM / MATRICULE / CLASSE / STATUTS).
Widget construireLigneColonnes({
  required Widget nom,
  required Widget prenom,
  required Widget matricule,
  required Widget classe,
  required Widget statut,
  required Widget actions,
}) {
  return Row(
    children: [
      Expanded(flex: 2, child: nom),
      Expanded(flex: 2, child: prenom),
      Expanded(flex: 2, child: matricule),
      Expanded(flex: 1, child: classe),
      Expanded(flex: 2, child: statut),
      SizedBox(width: _largeurColonneActions, child: Center(child: actions)),
    ],
  );
}

/// Page "Adhérents" (cf. cahier des charges - module "Gestion des
/// adhérents").
///
/// Toute la logique métier passe par [AdherentController] (RG-01,
/// RG-05) et [PretController] (statut d'emprunt de chaque adhérent).
class AdherentsPage extends StatefulWidget {
  const AdherentsPage({super.key});

  @override
  State<AdherentsPage> createState() => _AdherentsPageState();
}

class _AdherentsPageState extends State<AdherentsPage> {
  final AdherentController _adherentController = AdherentController();
  final AuthController _authController = AuthController();
  final PretController _pretController = PretController();

  final _ModuleSidebar _moduleActif = _ModuleSidebar.adherents;

  List<Adherent> _adherents = [];
  Map<int, _StatutAdherent> _statuts = {};
  bool _enChargement = true;

  /// `true` si la base ne contient réellement aucun adhérent (calculé
  /// uniquement lors des chargements sans filtre de recherche) — sert
  /// à distinguer "base vide" de "recherche sans résultat".
  bool _baseVide = true;

  /// Page courante de la pagination (0-indexée).
  int _pageActuelle = 0;

  /// Ligne dont le menu contextuel (crayon/poubelle) est ouvert : les
  /// autres lignes sont alors estompées.
  int? _menuOuvertPourId;

  ModeFormulaire _modeFormulaire = ModeFormulaire.masque;
  int? _idEnEdition;

  final TextEditingController _nomCtrl = TextEditingController();
  final TextEditingController _prenomCtrl = TextEditingController();
  final TextEditingController _numCarteCtrl = TextEditingController();
  final TextEditingController _classeCtrl = TextEditingController();
  final TextEditingController _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _chargerAdherents();
  }

  @override
  void dispose() {
    _nomCtrl.dispose();
    _prenomCtrl.dispose();
    _numCarteCtrl.dispose();
    _classeCtrl.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  // --- CHARGEMENT DES DONNÉES ---

  Future<void> _chargerAdherents({String? motCle}) async {
    setState(() => _enChargement = true);
    final filtre = motCle != null && motCle.isNotEmpty;
    final resultats = filtre
        ? await _adherentController.rechercher(nom: motCle)
        : await _adherentController.obtenirTous();
    if (!mounted) return;
    setState(() {
      _adherents = resultats;
      _enChargement = false;
      _pageActuelle = 0;
      // Ne recalculer "base vide" que lors d'un chargement sans
      // filtre, pour ne pas confondre "aucun résultat pour cette
      // recherche" avec "aucun adhérent en base".
      if (!filtre) _baseVide = resultats.isEmpty;
    });
    await _chargerStatuts();
  }

  /// Calcule le statut d'emprunt de chaque adhérent affiché, à partir
  /// de son historique réel : "En retard" prime sur "En cours", qui
  /// prime sur "Aucun emprunt".
  Future<void> _chargerStatuts() async {
    final Map<int, _StatutAdherent> statuts = {};
    for (final adherent in _adherents) {
      final id = adherent.idAdherent;
      if (id == null) continue;
      final historique = await _pretController.obtenirHistoriqueParAdherent(id);
      final List<Pret> enCours = historique.where((p) => p.estEnCours).toList();
      if (enCours.isEmpty) {
        statuts[id] = _StatutAdherent.aucunEmprunt;
      } else if (enCours.any((p) => p.estEnRetard)) {
        statuts[id] = _StatutAdherent.enRetard;
      } else {
        statuts[id] = _StatutAdherent.enCours;
      }
    }
    if (!mounted) return;
    setState(() => _statuts = statuts);
  }

  void _showToast(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message,
            style: GoogleFonts.quicksand(fontWeight: FontWeight.w600)),
        backgroundColor:
            isError ? const Color(0xFFB91C1C) : const Color(0xFF3B2470),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  /// Abréviation affichée dans la barre "compte" (ex. "admin" -> "Ad"),
  /// cf. nouvelle maquette : icône + courtes initiales à droite, sous
  /// la barre de titre.
  String get _libelleCompteCourant {
    final identifiant = _authController.utilisateurCourant?.identifiant ?? '';
    if (identifiant.isEmpty) return '';
    final prefixe =
        identifiant.length >= 2 ? identifiant.substring(0, 2) : identifiant;
    return prefixe[0].toUpperCase() + prefixe.substring(1).toLowerCase();
  }

  // --- PAGINATION ---

  int get _nombreDePages =>
      _adherents.isEmpty ? 1 : (_adherents.length / _taillePage).ceil();

  List<Adherent> get _adherentsPageCourante {
    if (_adherents.isEmpty) return const [];
    final debut = _pageActuelle * _taillePage;
    if (debut >= _adherents.length) return const [];
    final fin = (debut + _taillePage).clamp(0, _adherents.length);
    return _adherents.sublist(debut, fin);
  }

  // --- NAVIGATION SIDEBAR ---

  void _naviguerVersModule(_ModuleSidebar module) {
    switch (module) {
      case _ModuleSidebar.home:
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const AccueilPage()),
        );
        break;
      case _ModuleSidebar.adherents:
        // Déjà sur cette page.
        break;
      case _ModuleSidebar.livres:
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const LivresPage()),
        );
        break;
      case _ModuleSidebar.emprunts:
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const PretsPage()),
        );
        break;
      case _ModuleSidebar.tableauDeBord:
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const DashboardPage()),
        );
        break;
    }
  }

  // --- FORMULAIRE ---

  void _ouvrirFormulaireAjout() {
    setState(() {
      _modeFormulaire = ModeFormulaire.ajout;
      _idEnEdition = null;
      _menuOuvertPourId = null;
      _nomCtrl.clear();
      _prenomCtrl.clear();
      _numCarteCtrl.clear();
      _classeCtrl.clear();
    });
  }

  void _ouvrirFormulaireEdition(Adherent adherent) {
    setState(() {
      _modeFormulaire = ModeFormulaire.modification;
      _idEnEdition = adherent.idAdherent;
      _menuOuvertPourId = null;
      _nomCtrl.text = adherent.nom;
      _prenomCtrl.text = adherent.prenom;
      _numCarteCtrl.text = adherent.numCarte;
      _classeCtrl.text = adherent.classe;
    });
  }

  void _fermerFormulaire() {
    setState(() {
      _modeFormulaire = ModeFormulaire.masque;
      _idEnEdition = null;
    });
  }

  /// Enregistre les champs de saisie tels que tapés par
  /// l'utilisateur, sans transformation de casse — cf. demande de
  /// conserver les informations "telles qu'elles se présentent" :
  /// c'est la donnée réellement saisie qui est stockée. Seuls les
  /// libellés d'en-tête de colonnes sont volontairement mis en
  /// majuscules (cf. `_buildEnTeteColonnes`), pas les données.
  Future<void> _validerFormulaire() async {
    final nom = _nomCtrl.text.trim();
    final prenom = _prenomCtrl.text.trim();
    final numCarte = _numCarteCtrl.text.trim();
    final classe = _classeCtrl.text.trim();

    if (nom.isEmpty || prenom.isEmpty || numCarte.isEmpty) {
      _showToast('Veuillez remplir Nom, Prénom et Matricule.', isError: true);
      return;
    }

    final idUtilisateur = _authController.utilisateurCourant?.idUtilisateur;
    if (idUtilisateur == null) {
      _showToast('Session expirée, veuillez vous reconnecter.', isError: true);
      return;
    }

    ResultatOperation resultat;
    if (_modeFormulaire == ModeFormulaire.modification &&
        _idEnEdition != null) {
      final adherent = Adherent(
        idAdherent: _idEnEdition,
        numCarte: numCarte,
        nom: nom,
        prenom: prenom,
        classe: classe,
        idUtilisateur: idUtilisateur,
      );
      resultat = await _adherentController.modifier(adherent);
    } else {
      final adherent = Adherent(
        numCarte: numCarte,
        nom: nom,
        prenom: prenom,
        classe: classe,
        idUtilisateur: idUtilisateur,
      );
      final resultatAvecId = await _adherentController.inscrire(adherent);
      resultat = resultatAvecId.succes
          ? const ResultatOperation.succes()
          : ResultatOperation.echec(resultatAvecId.messageErreur);
    }

    if (!resultat.succes) {
      _showToast(resultat.messageErreur ?? 'Une erreur est survenue.',
          isError: true);
      return;
    }

    _showToast(_modeFormulaire == ModeFormulaire.modification
        ? 'Adhérent modifié'
        : 'Adhérent ajouté');
    _fermerFormulaire();
    await _chargerAdherents(motCle: _searchCtrl.text.trim());
  }

  Future<void> _confirmerSuppression(Adherent adherent) async {
    final confirme = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        title: Text('Supprimer cet adhérent ?',
            style: GoogleFonts.inter(fontWeight: FontWeight.bold)),
        content: Text(
            'Cette action est définitive pour ${adherent.nomComplet}.',
            style: GoogleFonts.roboto()),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Annuler'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Supprimer',
                style: TextStyle(color: Color(0xFFB91C1C))),
          ),
        ],
      ),
    );

    if (confirme != true) return;
    final id = adherent.idAdherent;
    if (id == null) return;
    await _supprimerAdherent(id);
  }

  Future<void> _supprimerAdherent(int id) async {
    final resultat = await _adherentController.supprimer(id);
    setState(() => _menuOuvertPourId = null);

    if (!resultat.succes) {
      _showToast(resultat.messageErreur ?? 'Suppression impossible.',
          isError: true);
      return;
    }

    await _chargerAdherents(motCle: _searchCtrl.text.trim());
    _showToast('Adhérent supprimé');
  }

  /// Clic sur un badge de statut, quel qu'il soit : ouvre le module
  /// Emprunts avec cet adhérent déjà pré-sélectionné, prêt à se voir
  /// attribuer un livre directement (cf. `PretsPage.adherentPreselectionne`).
  void _onStatutTap(Adherent adherent) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => PretsPage(adherentPreselectionne: adherent),
      ),
    );
  }

  // --- SIDEBAR ---

  Widget _buildSidebar() {
    // Sidebar en dégradé uni, sans décoration de formes en bas (cf.
    // demande explicite de retirer les "taches" décoratives).
    return Container(
      width: 240,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF4C3E87), Color(0xFF241A3E)],
        ),
      ),
      child: Column(
        children: [
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset('assets/icons/mon_logo.png',
                  fit: BoxFit.cover, width: 26, height: 26),
              const SizedBox(width: 10),
              Text('Bibliotech',
                  style: GoogleFonts.inter(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 16),
          const Divider(color: Color.fromARGB(155, 253, 252, 252), height: 1),
          const SizedBox(height: 12),
          _buildNavItem(_ModuleSidebar.home, Icons.home_outlined, 'Home'),
          _buildNavItem(
              _ModuleSidebar.adherents, Icons.people_alt_outlined, 'Adherents'),
          _buildNavItem(
              _ModuleSidebar.livres, Icons.menu_book_rounded, 'Livres'),
          _buildNavItem(
              _ModuleSidebar.emprunts, Icons.fact_check_outlined, 'Emprunts'),
          _buildNavItem(_ModuleSidebar.tableauDeBord, Icons.bar_chart_rounded,
              'Tableau de bord'),
        ],
      ),
    );
  }

  Widget _buildNavItem(_ModuleSidebar module, IconData icon, String label) {
    final estActif = module == _moduleActif;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          hoverColor: const Color.fromARGB(147, 233, 231, 238),
          onTap: () => _naviguerVersModule(module),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: estActif ? const Color(0xFFEDE9F7) : Colors.transparent,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              children: [
                Icon(icon,
                    color: estActif ? const Color(0xFF3B2470) : Colors.white70,
                    size: 22),
                const SizedBox(width: 12),
                Text(label,
                    style: GoogleFonts.inter(
                        color:
                            estActif ? const Color(0xFF3B2470) : Colors.white70,
                        fontWeight:
                            estActif ? FontWeight.w700 : FontWeight.w600,
                        fontSize: 15)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // --- BARRE "COMPTE" (sous la barre de titre) ---

  /// Bandeau coloré sous la barre de titre, contenant l'icône +
  /// initiales du compte connecté (cf. nouvelle maquette).
  Widget _buildBarreCompte() {
    return Container(
      height: 48,
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 24),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
          colors: [Color(0xFF6C5DAE), Color(0xFF3B2470)],
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          const CircleAvatar(
            radius: 14,
            backgroundColor: Colors.white24,
            child: Icon(Icons.person, color: Colors.white, size: 16),
          ),
          const SizedBox(width: 8),
          Text(_libelleCompteCourant,
              style: GoogleFonts.inter(
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                  fontSize: 14)),
        ],
      ),
    );
  }

  // --- BARRE DE RECHERCHE ---

  Widget _buildBarreRecherche() {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFFF3F1FA),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFDCD3F0)),
      ),
      child: TextField(
        controller: _searchCtrl,
        onChanged: (motCle) => _chargerAdherents(motCle: motCle.trim()),
        style: GoogleFonts.roboto(color: const Color(0xFF3B2470)),
        decoration: InputDecoration(
          hintText: 'Rechercher un adherent',
          hintStyle: GoogleFonts.inter(color: const Color(0xFF9C93B8)),
          // Icône de recherche à droite du champ, cf. nouvelle maquette.
          suffixIcon: const Icon(Icons.search, color: Color(0xFF7C6BC4)),
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
        ),
      ),
    );
  }

  // --- TABLEAU ---

  /// En-tête de colonnes en majuscules sur fond violet plein, cf.
  /// nouvelle maquette (NOM / PRENOM / MATRICULE / CLASSE / STATUTS).
  Widget _buildEnTeteColonnes() {
    final style = GoogleFonts.quicksand(
        fontWeight: FontWeight.w700,
        color: Colors.white,
        fontSize: 13,
        letterSpacing: 0.4);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
      decoration: const BoxDecoration(
        color: Color(0xFF5B4B95),
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(16),
          topRight: Radius.circular(16),
        ),
      ),
      child: construireLigneColonnes(
        nom: Text('NOM', style: style),
        prenom: Text('PRENOM', style: style),
        matricule: Text('MATRICULE', style: style),
        classe: Text('CLASSE', style: style),
        statut: Text('STATUTS', style: style),
        actions: const SizedBox.shrink(),
      ),
    );
  }

  Widget _buildTableCard() {
    if (_enChargement) {
      return const Center(
          child: CircularProgressIndicator(color: Color(0xFF5E4FA2)));
    }

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.05),
              blurRadius: 10,
              offset: const Offset(0, 4)),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: [
          if (_adherents.isNotEmpty) _buildEnTeteColonnes(),
          Expanded(
            child: _adherents.isEmpty
                ? _buildEmptyState()
                : _buildListeAdherents(),
          ),
          if (_adherents.isNotEmpty) _buildPagination(),
        ],
      ),
    );
  }

  /// État vide, avec 3 cas distincts :
  /// 1. Le formulaire est déjà ouvert (ajout/modification).
  /// 2. Une recherche est active et ne donne aucun résultat, alors
  ///    qu'il existe bien des adhérents en base.
  /// 3. La base est réellement vide.
  Widget _buildEmptyState() {
    final rechercheActive = _searchCtrl.text.trim().isNotEmpty;
    final formulaireOuvert = _modeFormulaire != ModeFormulaire.masque;

    if (formulaireOuvert) {
      return Center(
        child: Text(
          rechercheActive
              ? 'Aucun résultat pour cette recherche.'
              : 'Aucun adhérent enregistré pour le moment.',
          style: GoogleFonts.nunito(color: const Color(0xFF9C93B8)),
          textAlign: TextAlign.center,
        ),
      );
    }

    if (rechercheActive && !_baseVide) {
      return Center(
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.search_off, size: 44, color: Color(0xFFB9AEDD)),
              const SizedBox(height: 12),
              Text('Aucun résultat pour « ${_searchCtrl.text.trim()} »',
                  style: GoogleFonts.inter(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xFF3B2470)),
                  textAlign: TextAlign.center),
              const SizedBox(height: 6),
              Text(
                'Il existe des adhérents enregistrés, mais aucun ne correspond à cette recherche.',
                textAlign: TextAlign.center,
                style: GoogleFonts.inter(color: const Color(0xFF9C93B8)),
              ),
              const SizedBox(height: 14),
              TextButton.icon(
                onPressed: () {
                  _searchCtrl.clear();
                  _chargerAdherents();
                },
                icon: const Icon(Icons.close, size: 18),
                label: const Text('Réinitialiser la recherche'),
              ),
            ],
          ),
        ),
      );
    }

    return Center(
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.people_outline,
                size: 48, color: Color(0xFFB9AEDD)),
            const SizedBox(height: 12),
            Text('Aucun adhérent enregistré',
                style: GoogleFonts.quicksand(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: const Color(0xFF3B2470))),
            const SizedBox(height: 6),
            Text(
              'Ajoutez votre premier adhérent pour commencer à gérer les emprunts.',
              textAlign: TextAlign.center,
              style: GoogleFonts.inter(color: const Color(0xFF9C93B8)),
            ),
            const SizedBox(height: 14),
            ElevatedButton.icon(
              onPressed: _ouvrirFormulaireAjout,
              icon: const Icon(Icons.add, size: 20),
              label: Text('Ajouter un adhérent',
                  style: GoogleFonts.inter(fontWeight: FontWeight.bold)),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF5E4FA2),
                foregroundColor: Colors.white,
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
                elevation: 0,
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Liste avec lignes de séparation, sans défilement interne — la
  /// navigation se fait par pagination (`_buildPagination`) plutôt que
  /// par scroll, cf. nouvelle maquette.
  Widget _buildListeAdherents() {
    final page = _adherentsPageCourante;
    return GestureDetector(
      onTap: () => setState(() => _menuOuvertPourId = null),
      child: ListView.separated(
        physics: const NeverScrollableScrollPhysics(),
        itemCount: page.length,
        separatorBuilder: (context, index) => const Divider(
          height: 1,
          thickness: 1,
          color: Color(0xFFE9E3F6),
          indent: 12,
          endIndent: 12,
        ),
        itemBuilder: (context, index) {
          final adherent = page[index];
          final id = adherent.idAdherent;
          final menuOuvert = id != null && _menuOuvertPourId == id;
          final autreMenuOuvert = _menuOuvertPourId != null && !menuOuvert;

          return _LigneAdherentWidget(
            key: ValueKey(id ?? adherent.numCarte),
            adherent: adherent,
            statut: id != null ? _statuts[id] : null,
            menuOuvert: menuOuvert,
            autreMenuOuvert: autreMenuOuvert,
            onToggleMenu: id == null
                ? null
                : () =>
                    setState(() => _menuOuvertPourId = menuOuvert ? null : id),
            onEdit: () => _ouvrirFormulaireEdition(adherent),
            onDelete: () => _confirmerSuppression(adherent),
            onStatutTap: () => _onStatutTap(adherent),
          );
        },
      ),
    );
  }

  /// Pagination (cf. nouvelle maquette : "1 2 3 ... 10" en bas de la
  /// carte liste, plus de défilement interne). Fenêtre de pages
  /// affichées : première, dernière, et les pages autour de la
  /// courante, avec "…" pour les sauts.
  Widget _buildPagination() {
    final total = _nombreDePages;
    if (total <= 1) return const SizedBox(height: 8);

    final pagesAffichees = <int>{0, total - 1};
    for (var p = _pageActuelle - 1; p <= _pageActuelle + 1; p++) {
      if (p >= 0 && p < total) pagesAffichees.add(p);
    }
    final pages = pagesAffichees.toList()..sort();

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          IconButton(
            icon: const Icon(Icons.chevron_left),
            color: const Color(0xFF5E4FA2),
            splashRadius: 18,
            onPressed: _pageActuelle > 0
                ? () => setState(() => _pageActuelle--)
                : null,
          ),
          for (var i = 0; i < pages.length; i++) ...[
            if (i > 0 && pages[i] - pages[i - 1] > 1)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Text('…',
                    style:
                        GoogleFonts.inter(color: const Color(0xFF9C93B8))),
              ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 3),
              child: InkWell(
                borderRadius: BorderRadius.circular(8),
                onTap: () => setState(() => _pageActuelle = pages[i]),
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: pages[i] == _pageActuelle
                        ? const Color(0xFF5E4FA2)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    '${pages[i] + 1}',
                    style: GoogleFonts.inter(
                      fontWeight: FontWeight.w700,
                      color: pages[i] == _pageActuelle
                          ? Colors.white
                          : const Color(0xFF3B2470),
                    ),
                  ),
                ),
              ),
            ),
          ],
          IconButton(
            icon: const Icon(Icons.chevron_right),
            color: const Color(0xFF5E4FA2),
            splashRadius: 18,
            onPressed: _pageActuelle < total - 1
                ? () => setState(() => _pageActuelle++)
                : null,
          ),
        ],
      ),
    );
  }

  // --- FORMULAIRE ---

  Widget _buildFormulaire() {
    if (_modeFormulaire == ModeFormulaire.masque) {
      return const SizedBox.shrink();
    }
    final estEdition = _modeFormulaire == ModeFormulaire.modification;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOut,
      margin: const EdgeInsets.only(top: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE2DBF1), width: 1.5),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withValues(alpha: 0.05),
              blurRadius: 8,
              offset: const Offset(0, 3)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(estEdition ? "Modifier l'adhérent" : 'Nouvel adhérent',
                  style: GoogleFonts.quicksand(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xFF3B2470))),
              IconButton(
                icon: const Icon(Icons.close, color: Colors.grey, size: 20),
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
                onPressed: _fermerFormulaire,
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: _buildChamp('Nom', _nomCtrl)),
              const SizedBox(width: 12),
              Expanded(child: _buildChamp('Prénom', _prenomCtrl)),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: _buildChamp('Matricule', _numCarteCtrl)),
              const SizedBox(width: 12),
              Expanded(child: _buildChamp('Classe', _classeCtrl)),
            ],
          ),
          const SizedBox(height: 14),
          Align(
            alignment: Alignment.centerRight,
            child: ElevatedButton(
              onPressed: _validerFormulaire,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF5E4FA2),
                foregroundColor: Colors.white,
                padding:
                    const EdgeInsets.symmetric(horizontal: 28, vertical: 10),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8)),
                elevation: 0,
              ),
              child: Text(estEdition ? 'Modifier' : 'Ajouter',
                  style: GoogleFonts.quicksand(
                      fontWeight: FontWeight.w700, fontSize: 14)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChamp(String label, TextEditingController controller) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: GoogleFonts.inter(
                color: const Color(0xFF3B2470),
                fontWeight: FontWeight.w700,
                fontSize: 13)),
        const SizedBox(height: 4),
        TextField(
          controller: controller,
          style: GoogleFonts.inter(fontSize: 14),
          decoration: InputDecoration(
            isDense: true,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide:
                  const BorderSide(color: Color(0xFFCFC6E8), width: 1.2),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide:
                  const BorderSide(color: Color(0xFFCFC6E8), width: 1.2),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide:
                  const BorderSide(color: Color(0xFF7C3AED), width: 1.6),
            ),
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
          ),
        ),
      ],
    );
  }

  // --- ASSEMBLAGE ---

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(
        children: [
          _buildSidebar(),
          Expanded(
            child: Column(
              children: [
                // Barre de titre : logo + "Bibliotech" à gauche (plus
                // de titre de module centré ici, cf. nouvelle maquette).
                BarreTitrePersonnalisee(
                  leading: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Image.asset('assets/icons/mon_logo.png',
                          width: 22, height: 22, fit: BoxFit.cover),
                      const SizedBox(width: 8),
                      Text('Bibliotech',
                          style: GoogleFonts.inter(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                              color: const Color(0xFF3B2470))),
                    ],
                  ),
                ),
                _buildBarreCompte(),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(_titrePage,
                                style: GoogleFonts.quicksand(
                                    fontSize: 24,
                                    fontWeight: FontWeight.bold,
                                    color: const Color(0xFF3B2470))),
                            ElevatedButton.icon(
                              onPressed: _ouvrirFormulaireAjout,
                              icon: const Icon(Icons.add, size: 20),
                              label: Text('Nouveau',
                                  style: GoogleFonts.quicksand(
                                      fontWeight: FontWeight.bold)),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFF5E4FA2),
                                foregroundColor: Colors.white,
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 24, vertical: 14),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10)),
                                elevation: 0,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 20),
                        _buildBarreRecherche(),
                        const SizedBox(height: 16),
                        Expanded(child: _buildTableCard()),
                        _buildFormulaire(),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Une ligne du tableau, extraite en widget à état propre : son survol
/// (`MouseRegion`) est géré localement plutôt que remonté dans
/// `_AdherentsPageState`, pour éviter le clignotement au survol.
class _LigneAdherentWidget extends StatefulWidget {
  final Adherent adherent;
  final _StatutAdherent? statut;
  final bool menuOuvert;
  final bool autreMenuOuvert;
  final VoidCallback? onToggleMenu;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final VoidCallback onStatutTap;

  const _LigneAdherentWidget({
    super.key,
    required this.adherent,
    required this.statut,
    required this.menuOuvert,
    required this.autreMenuOuvert,
    required this.onToggleMenu,
    required this.onEdit,
    required this.onDelete,
    required this.onStatutTap,
  });

  @override
  State<_LigneAdherentWidget> createState() => _LigneAdherentWidgetState();
}

class _LigneAdherentWidgetState extends State<_LigneAdherentWidget> {
  bool _survolee = false;

  @override
  Widget build(BuildContext context) {
    final style =
        GoogleFonts.inter(color: const Color(0xFF3B2470), fontSize: 15);
    final adherent = widget.adherent;

    Widget ligne = MouseRegion(
      onEnter: (_) => setState(() => _survolee = true),
      onExit: (_) => setState(() => _survolee = false),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        decoration: BoxDecoration(
          color: widget.menuOuvert
              ? const Color(0xFFDCD3F0)
              : (_survolee ? const Color(0xFFF1EDFA) : Colors.transparent),
          borderRadius: BorderRadius.circular(14),
          boxShadow: widget.menuOuvert
              ? [
                  BoxShadow(
                    color: Colors.purple.withValues(alpha: 0.35),
                    blurRadius: 15,
                    spreadRadius: 1,
                    offset: const Offset(0, 6),
                  ),
                ]
              : (_survolee
                  ? [
                      BoxShadow(
                        color: Colors.purple.withValues(alpha: 0.12),
                        blurRadius: 8,
                        offset: const Offset(0, 3),
                      ),
                    ]
                  : const []),
        ),
        child: construireLigneColonnes(
          // Les données sont affichées telles que saisies par
          // l'utilisateur (pas de transformation de casse forcée) —
          // seuls les en-têtes de colonnes sont en majuscules.
          nom: Text(adherent.nom, style: style),
          prenom: Text(adherent.prenom, style: style),
          matricule: Text(adherent.numCarte, style: style),
          classe: Text(adherent.classe, style: style),
          statut: _buildBadgeStatut(),
          actions: widget.menuOuvert
              ? _buildMenuFlottant()
              : IconButton(
                  icon: const Icon(Icons.more_horiz, color: Color(0xFF6B5FA8)),
                  onPressed: widget.onToggleMenu,
                ),
        ),
      ),
    );

    if (widget.autreMenuOuvert) {
      ligne = Opacity(opacity: 0.55, child: ligne);
    }

    return ligne;
  }

  Widget _buildMenuFlottant() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 2),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.12),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            icon: const Icon(Icons.edit,
                color: Color.fromARGB(255, 93, 56, 179), size: 17),
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
            splashRadius: 18,
            onPressed: widget.onEdit,
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline,
                color: Color.fromARGB(255, 240, 42, 42), size: 17),
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
            splashRadius: 18,
            onPressed: widget.onDelete,
          ),
        ],
      ),
    );
  }

  /// Couleurs des 3 statuts, "En cours" en vert (cf. nouvelle maquette).
  Widget _buildBadgeStatut() {
    late final Color fond;
    late final Color texte;
    late final String label;

    switch (widget.statut) {
      case _StatutAdherent.enRetard:
        fond = const Color(0xFFFCE8E8);
        texte = const Color(0xFFB91C1C);
        label = 'En retard';
        break;
      case _StatutAdherent.enCours:
        fond = const Color(0xFFE3F6E7);
        texte = const Color(0xFF2E7D32);
        label = 'En cours';
        break;
      case _StatutAdherent.aucunEmprunt:
      default:
        fond = const Color(0xFFEDE9F7);
        texte = const Color(0xFF7C6BC4);
        label = 'Aucun emprunt';
    }

    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: widget.onStatutTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration:
            BoxDecoration(color: fond, borderRadius: BorderRadius.circular(20)),
        child: Text(
          label,
          style: GoogleFonts.inter(
              color: texte, fontWeight: FontWeight.w700, fontSize: 12),
        ),
      ),
    );
  }
}
